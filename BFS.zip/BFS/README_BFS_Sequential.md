# Bài Toán RL: Tìm Mục Tiêu Tuần Tự Với Q-Learning

## 🎯 Mô Tả Bài Toán

### **Bối Cảnh**
Agent (xe ô tô 🚗) phải điều hướng trong mê cung 10×10 để đạt được 5 mục tiêu 🏠 theo thứ tự tuần tự. Mỗi khi đạt được một mục tiêu, mục tiêu đó sẽ trở thành chướng ngại vật đen (không thể đi qua), làm cho bài toán ngày càng khó khăn.

### **Môi Trường Grid**
- **Kích thước**: 10×10 ô vuông
- **Chướng ngại vật cố định**: Ô đen (1) - không thể đi qua
- **Đường đi**: Ô trắng (0) - có thể di chuyển tự do
- **Vị trí bắt đầu**: (5, 9) - cố định
- **5 Mục tiêu** cần đạt theo thứ tự:
  1. Goal 1: (0, 1) 
  2. Goal 2: (7, 2)
  3. Goal 3: (2, 4)
  4. Goal 4: (2, 6)
  5. Goal 5: (9, 8)

### **Luật Chơi và Flow**
1. **Bắt đầu**: Agent ở vị trí Start (5, 9)
2. **Mục tiêu đầu tiên**: Đi đến Goal 1 tại (0, 1)
3. **Di chuyển**: Agent có thể di chuyển LÊN, XUỐNG, TRÁI, PHẢI (4 hướng)
4. **Đạt được Goal**: 
   - Nhận +10 điểm thưởng
   - Xe vào đúng ô của Goal (hiển thị rõ ràng)
   - Goal đó trở thành chướng ngại vật đen (không thể đi qua)
5. **Reset về Start**: Agent tự động về lại vị trí Start (5, 9)
6. **Lặp lại**: Tiếp tục với Goal tiếp theo
7. **Hoàn thành**: Đạt được tất cả 5 goals

**Flow chi tiết:**
```
Start (5,9) 
  → Đi đến Goal 1 
  → Xe vào ô Goal 1 (hiển thị rõ) 
  → Reset về Start (5,9) 
  → Goal 1 hóa đen (BLOCKED)
  → Đi đến Goal 2 
  → Xe vào ô Goal 2 
  → Reset về Start 
  → Goal 2 hóa đen
  → ... (tiếp tục cho đến Goal 5)
```

### **Đặc Điểm Đặc Biệt**
- **Sequential Goals**: Phải đạt G1 → G2 → G3 → G4 → G5 theo đúng thứ tự
- **Dynamic Obstacles**: Goals đã đạt trở thành chướng ngại vật đen vĩnh viễn
- **Position Reset**: Agent luôn reset về Start (5,9) sau mỗi goal
- **Increasing Difficulty**: Mỗi goal đạt được làm môi trường phức tạp hơn (ít đường đi hơn)

### **State Space (Không gian Trạng thái)**
```
State = (row, col, goal_index)
- row, col: 0-9 (100 vị trí có thể)
- goal_index: 0-5 (6 trạng thái: chưa đạt goal nào, đã đạt 1 goal, ..., đã đạt 5 goals)
- Tổng số states: 100 × 6 = 600 states
```

### **Action Space (Không gian Hành động)**
- **UP**: Di chuyển lên (-1, 0)
- **DOWN**: Di chuyển xuống (+1, 0)
- **LEFT**: Di chuyển trái (0, -1)
- **RIGHT**: Di chuyển phải (0, +1)

### **Reward Structure (Cơ cấu Phần thưởng)**
- **Đạt được Goal**: +10 điểm (phần thưởng lớn)
- **Di chuyển hợp lệ**: -1 điểm (penalty nhỏ để khuyến khích đường ngắn)
- **Di chuyển không hợp lệ**: -1 điểm (vẫn bị penalty, nhưng giữ nguyên vị trí)

### **Điều kiện Kết thúc**
- **Thành công**: Đạt được tất cả 5 goals
- **Giới hạn bước**: Tối đa 2000 steps trong evaluation (tránh vòng lặp vô hạn)

## 🧠 Thuật Toán Q-Learning

### **Q-Learning là gì?**
Q-Learning là một thuật toán **Reinforcement Learning (RL) off-policy**, học được policy tối ưu bằng cách cập nhật Q-values dựa trên action tốt nhất ở trạng thái tiếp theo (không cần follow policy hiện tại).

### **Công thức Bellman Equation**
```
Q(s,a) = Q(s,a) + α[r + γ*max(Q(s',a')) - Q(s,a)]

Trong đó:
- Q(s,a): Giá trị Q của state s và action a
- α (alpha): Learning rate (tốc độ học) = 0.1
- r: Reward nhận được
- γ (gamma): Discount factor (hệ số chiết khấu) = 0.9
- max(Q(s',a')): Giá trị Q lớn nhất ở next state s'
```

### **Đặc điểm Q-Learning (Off-Policy)**
- **Off-policy**: Học optimal policy trong khi có thể follow policy khác (ε-greedy)
- **max(Q(s',a'))**: Sử dụng action tốt nhất ở next state, không phải action thực tế được chọn
- **Không cần policy model**: Chỉ cần Q-table để học

### **Tham số Training**
- **Learning Rate (α)**: 0.1 - Tốc độ cập nhật Q-values
- **Discount Factor (γ)**: 0.9 - Trọng số cho phần thưởng tương lai
- **Exploration Rate (ε)**: 
  - Khởi tạo: 1.0 (100% exploration)
  - Decay: 0.995 (giảm dần mỗi episode)
  - Minimum: 0.01 (tối thiểu 1% exploration)
- **Training Episodes**: 1000 episodes
- **Max Steps per Episode**: 200 steps (tránh vòng lặp vô hạn)

### **Quy trình Training**
1. **Khởi tạo**: Q-table rỗng (defaultdict, tự động tạo giá trị 0.0)
2. **Vòng lặp Episode**: 1000 episodes
   - Reset environment về trạng thái ban đầu
   - Vòng lặp Step: Tối đa 200 steps
     - Chọn action bằng ε-greedy policy
     - Thực hiện action → nhận (next_state, reward, done)
     - Cập nhật Q-value theo Bellman equation
     - Chuyển sang next state
   - Lưu thống kê (reward, steps)
   - Decay epsilon (giảm exploration, tăng exploitation)
3. **Kết quả**: Q-table chứa Q-values đã học cho các (state, action) pairs

### **ε-Greedy Policy (Chính sách Tham lam Epsilon)**
- **Exploration (ε)**: Random action để khám phá môi trường
- **Exploitation (1-ε)**: Chọn action có Q-value cao nhất
- **Cân bằng**: Ban đầu explore nhiều, sau đó exploit nhiều hơn

### **Evaluation (Đánh giá)**
- **Greedy Policy**: Chỉ chọn action tốt nhất (ε = 0, không exploration)
- **Sử dụng Q-values đã học**: Agent đi theo đường đi tối ưu
- **Visualization**: Hiển thị animation từng bước di chuyển

## 🎨 Visualization & Animation

### **Real-time Animation Features**
- **Xe di chuyển từng bước**: 🚗 hiển thị vị trí hiện tại
- **Đánh dấu Goals**: 🏠 với số thứ tự G1-G5
- **Goals đã đạt**: Hiển thị "BLOCKED" màu đen
- **Start Position**: Màu xanh lá với nhãn "START"
- **Status Updates**: Hiển thị goal hiện tại, action, vị trí, số bước

### **Flow Animation**
1. **Di chuyển bình thường**: Xe di chuyển từng bước với delay 0.3s
2. **Khi đạt Goal**:
   - Xe vào đúng ô của Goal (hiển thị rõ ràng)
   - Pause 1s để thấy xe trong ô Goal
   - Goal hóa đen (redraw grid)
   - Xe biến mất và reset về Start
   - Pause 1s để thấy reset
3. **Tiếp tục**: Lặp lại cho goal tiếp theo

### **Training Progress Visualization**
- **Learning Curves**: Biểu đồ reward theo episodes
- **Moving Average**: Trung bình động 50 episodes (smooth curve)
- **Statistics**: Số lượng Q-values đã học, epsilon cuối cùng, thời gian training

### **Evaluation Visualization**
- **Path Display**: Đường đi từ Start đến từng Goal
- **Goal Status**: Goals còn lại vs Goals đã đạt (đen)
- **Performance Metrics**: Tổng số bước, reward, goals completed

## 📊 Kết Quả Thí Nghiệm

### **Training Performance**
```
Số Episodes: 1000
Q-values đã học: ~1100-1200 (state-action pairs)
Epsilon cuối cùng: 0.01
Thời gian training: ~0.3-0.5 giây
```

### **Learning Curve (Đường cong Học)**
- **Episode 100**: Reward ≈ -192 (agent còn random nhiều)
- **Episode 500**: Reward ≈ -16 (agent đã học được đường đi tốt hơn)
- **Episode 1000**: Reward ≈ -7.6 (agent gần như tối ưu)

### **Evaluation Results (Kết quả Đánh giá)**
- **Success Rate**: 100% (đạt được tất cả 5/5 goals)
- **Total Steps**: ~50-60 steps (tùy thuộc vào đường đi)
- **Final Reward**: ~-7 đến -10 (đạt 5 goals × +10, trừ penalty cho các bước)

## 🔧 Chi Tiết Implementation

### **Classes Chính**

#### **1. GridEnvironment**
```python
- __init__(): Khởi tạo grid 10×10, obstacles, goals, start position
- reset(): Reset về trạng thái ban đầu, trả về initial state
- step(action): Thực hiện action, trả về (next_state, reward, done, info)
  * Di chuyển agent
  * Kiểm tra goal đạt được
  * Chuyển goal thành obstacle
  * Reset về start cho goal tiếp theo
- _get_state(): Trả về state dạng (row, col, goal_index)
- _is_valid_position(): Kiểm tra vị trí hợp lệ (không obstacle, trong bounds)
```

#### **2. QLearningAgent**
```python
- __init__(): Khởi tạo Q-table, hyperparameters
- get_action(state, training): ε-greedy policy
  * Training: Random với xác suất ε, best action với xác suất (1-ε)
  * Evaluation: Chỉ chọn best action (greedy)
- update_q(state, action, reward, next_state): Cập nhật Q-value theo Bellman
- train(num_episodes): Training loop với ε-decay
- evaluate_episode(): Đánh giá với greedy policy, trả về trajectory
- decay_epsilon(): Giảm exploration rate
```

### **Key Methods**

#### **step(action) - Quan trọng nhất**
```python
def step(self, action):
    # 1. Tính toán next position
    next_pos = current_pos + action_delta
    
    # 2. Kiểm tra valid move
    if valid:
        current_pos = next_pos
        reward = -1
    else:
        reward = -1  # Stay in place
    
    # 3. Kiểm tra goal đạt được
    if current_pos == current_goal:
        reward += 10
        achieved_goals.add(goal)
        grid[goal] = 1  # Goal thành obstacle
        current_goal_idx += 1
        
        if all_goals_completed:
            done = True
        else:
            current_pos = start_pos  # Reset về start
    
    return (next_state, reward, done, info)
```

#### **update_q() - Q-Learning Core**
```python
def update_q(self, state, action, reward, next_state):
    current_q = Q[(state, action)]
    
    # Q-Learning: Sử dụng max(Q(s',a')) - OFF-POLICY
    if not done:
        next_max_q = max([Q[(next_state, a)] for a in actions])
    else:
        next_max_q = 0
    
    target = reward + gamma * next_max_q
    Q[(state, action)] = current_q + alpha * (target - current_q)
```

### **Technical Features**

#### **Dynamic Grid Management**
- Goals đạt được tự động chuyển thành obstacles trong grid
- Grid được redraw sau mỗi goal để hiển thị obstacles mới
- State space bao gồm goal_index để phân biệt các giai đoạn

#### **Position Reset Logic**
- Sau mỗi goal, agent tự động về Start (5,9)
- Goal index tăng lên để tracking goal tiếp theo
- Environment state được cập nhật chính xác

#### **Unicode & Emoji Support**
- Sử dụng emoji: 🚗 (xe), 🏠 (goal), 🏆 (hoàn thành)
- Font config: 'Segoe UI Emoji' (Windows) để hiển thị đúng
- Color coding: Xanh (start), Đỏ (goals), Đen (obstacles)

## 🎯 Bài Học về Reinforcement Learning

### **Concepts Quan Trọng**

#### **1. Exploration vs Exploitation**
- **Exploration**: Khám phá các actions mới, có thể tốt hơn
- **Exploitation**: Sử dụng knowledge đã học để chọn action tốt nhất
- **ε-greedy**: Cân bằng giữa 2 yếu tố, decay theo thời gian

#### **2. Sequential Decision Making**
- Agent phải plan nhiều bước trước
- Q-values tích lũy reward tương lai (discount factor γ)
- Optimal path không chỉ là đường ngắn nhất, mà còn tránh obstacles tương lai

#### **3. Dynamic Environments**
- Môi trường thay đổi khi goals trở thành obstacles
- Agent phải adapt với environment mới
- Q-values phải học được nhiều scenarios khác nhau

#### **4. Sparse Rewards**
- Chỉ có reward +10 khi đạt goal, còn lại đều -1
- Agent phải học được rằng goal là mục tiêu cuối cùng
- Long-term planning quan trọng hơn immediate rewards

#### **5. State Representation**
- State = (row, col, goal_index) - Quan trọng để phân biệt context
- Một vị trí (5,9) có thể là state khác nhau tùy goal_index
- State space design ảnh hưởng lớn đến learning performance

### **Q-Learning vs Các Thuật Toán Khác**

#### **Q-Learning (Code này) - Off-Policy**
```
Update: Q(s,a) = Q(s,a) + α[r + γ*max(Q(s',a')) - Q(s,a)]
- Học optimal policy
- Không cần follow policy hiện tại
- Có thể học từ experience của policy khác
```

#### **SARSA - On-Policy**
```
Update: Q(s,a) = Q(s,a) + α[r + γ*Q(s',a') - Q(s,a)]
- a' là action thực tế được chọn ở next state
- Học policy đang follow
- An toàn hơn (không chọn action nguy hiểm)
```

#### **BFS (Breadth-First Search) - Không phải RL**
```
- Tìm đường đi ngắn nhất từ Start đến Goal
- Không học từ experience
- Không handle dynamic obstacles tốt
- Chạy lại từ đầu mỗi lần
```

### **Challenges trong Bài Toán**

#### **1. Blocked Paths**
- Goals đã đạt trở thành obstacles vĩnh viễn
- Agent phải tìm đường đi khác khi path bị block
- Q-values phải học được nhiều alternative paths

#### **2. Optimal Routing**
- Không chỉ tìm đường ngắn nhất đến goal hiện tại
- Phải consider obstacles sẽ xuất hiện sau này
- Long-term planning với discount factor

#### **3. Memory & Adaptation**
- Agent phải nhớ vị trí các goals đã đạt
- State space bao gồm goal_index để tracking
- Adapt strategy khi environment thay đổi

## 🚀 Cách Chạy Demo

### **Chạy Animated Demo (Khuyến nghị)**
```bash
cd D:\BFS
python BFS.py
```

Chương trình sẽ:
1. Tạo environment 10×10 với 5 goals
2. Training Q-Learning agent (1000 episodes, ~0.3s)
3. Reset environment về clean state
4. Chạy animated evaluation:
   - Xe di chuyển từng bước đến Goal 1
   - Xe vào ô Goal 1 → Pause 1s
   - Goal 1 hóa đen → Reset về Start
   - Tiếp tục với Goal 2-5
   - Hiển thị kết quả cuối cùng

### **Lưu Ý**
- **Matplotlib Window**: Giữ cửa sổ matplotlib mở để xem animation
- **Delay**: Mặc định 0.3s giữa mỗi bước (có thể điều chỉnh trong code)
- **Training Time**: Rất nhanh (~0.3-0.5s) do Q-table nhỏ
- **Evaluation**: Chạy với greedy policy (không exploration)

### **Tùy chỉnh Hyperparameters**
```python
# Trong run_animated_demo():
agent = QLearningAgent(
    env, 
    alpha=0.1,      # Learning rate (tăng = học nhanh hơn, nhưng không ổn định)
    gamma=0.9,      # Discount factor (tăng = quan trọng rewards tương lai hơn)
    epsilon=1.0     # Initial exploration (1.0 = 100% random ban đầu)
)

agent.train(
    num_episodes=1000,           # Số episodes training
    max_steps_per_episode=200    # Max steps per episode
)
```

## 📈 Performance Tips

### **Để Cải thiện Performance**
1. **Tăng số episodes**: 2000-5000 episodes cho learning tốt hơn
2. **Điều chỉnh learning rate**: α = 0.2-0.3 cho học nhanh hơn
3. **Discount factor**: γ = 0.95-0.99 cho long-term planning tốt hơn
4. **Epsilon decay**: Chậm hơn (0.998) để explore nhiều hơn

### **Troubleshooting**
- **Agent không học được**: Tăng episodes, kiểm tra reward structure
- **Agent đi vòng**: Tăng penalty cho invalid moves (-5 thay vì -1)
- **Animation chậm**: Giảm delay trong animate_car_movement()
- **Goal không hiển thị đen**: Kiểm tra redraw_grid() được gọi đúng

## 🎊 Kết Luận

Bài toán này minh họa rõ ràng **Q-Learning** trong một môi trường động với các đặc điểm:

### **Ưu điểm của Q-Learning**
- ✅ **Off-policy**: Học optimal policy mà không cần follow policy hiện tại
- ✅ **Model-free**: Không cần biết transition probabilities
- ✅ **Tabular**: Dễ hiểu và implement cho không gian nhỏ
- ✅ **Convergence**: Đảm bảo hội tụ về optimal Q-values (với điều kiện)

