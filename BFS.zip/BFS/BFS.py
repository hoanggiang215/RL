"""
Grid-based RL Environment with Sequential Goals and Q-Learning

Requirements:
- 10×10 grid with obstacles
- Fixed start position
- 5 goals that must be reached sequentially
- Q-learning with ε-greedy exploration
- Agent selects actions automatically
- Episodes terminate after all goals completed
- Training stops after fixed number of episodes
- Visualize one evaluation episode using greedy policy
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import random
from collections import defaultdict
import time

# Cấu hình font hỗ trợ emoji (rất quan trọng!)
plt.rcParams['font.family'] = 'Segoe UI Emoji'  # Windows: font có sẵn hỗ trợ emoji đầy đủ
# Nếu dùng macOS: 'Apple Color Emoji'
# Nếu dùng Linux: 'Noto Color Emoji'

class GridEnvironment:
    """
    10×10 Grid Environment with obstacles and sequential goals
    """

    def __init__(self):
        # Define the 10×10 grid (1 = obstacle/wall, 0 = free space)
        self.original_grid = np.array([
            [1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
            [1, 0, 1, 1, 1, 1, 1, 1, 0, 0],
            [0, 0, 0, 1, 0, 1, 0, 1, 1, 0],
            [0, 1, 0, 0, 0, 1, 0, 0, 1, 0],
            [0, 1, 1, 1, 1, 1, 0, 1, 1, 0],
            [0, 0, 0, 1,  0, 1, 0, 0, 0, 0],
            [0, 1, 0, 0, 0, 0, 0, 1, 1, 1],
            [0, 1, 0, 1, 1, 0, 0, 0, 0, 1],
            [0, 1, 1, 0, 1, 1, 1, 0, 1, 1],
            [0, 0, 0, 0, 0, 0, 0, 0, 0, 1]
        ])

        # Copy grid để có thể modify
        self.grid = self.original_grid.copy()

        # Fixed start position
        self.start_pos = (5, 9)  # (row, col)

        # 5 goals that must be reached sequentially
        self.goals = [(0, 1), (7, 2), (2, 4), (2, 6), (9, 8)]

        # Track achieved goals (these become obstacles)
        self.achieved_goals = set()

        # Environment dimensions
        self.rows, self.cols = self.grid.shape

        # Actions: 0=UP, 1=DOWN, 2=LEFT, 3=RIGHT
        self.actions = ['UP', 'DOWN', 'LEFT', 'RIGHT']
        self.action_deltas = {
            'UP': (-1, 0),
            'DOWN': (1, 0),
            'LEFT': (0, -1),
            'RIGHT': (0, 1)
        }

        # State space: (row, col, goal_index)
        # goal_index ranges from 0 to len(goals) (0 = no goals achieved yet)
        self.num_states = self.rows * self.cols * (len(self.goals) + 1)

        # Reset environment
        self.reset()

    def reset(self):
        """Reset environment to initial state"""
        # Reset grid về trạng thái ban đầu
        self.grid = self.original_grid.copy()

        # Reset achieved goals
        self.achieved_goals = set()

        # Reset position and goal index
        self.current_pos = self.start_pos
        self.current_goal_idx = 0  # Start with goal 0
        self.done = False

        return self._get_state()

    def _get_state(self):
        """Return current state as tuple (row, col, goal_index)"""
        return (self.current_pos[0], self.current_pos[1], self.current_goal_idx)

    def _is_valid_position(self, pos):
        """Check if position is valid (within bounds and not obstacle)"""
        r, c = pos
        return (0 <= r < self.rows and 0 <= c < self.cols and
                self.grid[r, c] == 0)  # 0 = free space

    def step(self, action):
        """
        Execute action and return (next_state, reward, done, info)

        Args:
            action (str): Action to take ('UP', 'DOWN', 'LEFT', 'RIGHT')

        Returns:
            next_state: New state after action
            reward: Reward received
            done: Whether episode is finished
            info: Additional information
        """
        if self.done:
            return self._get_state(), 0, True, {}

        # Calculate next position
        dr, dc = self.action_deltas[action]
        next_pos = (self.current_pos[0] + dr, self.current_pos[1] + dc)

        # Check if move is valid
        if self._is_valid_position(next_pos):
            self.current_pos = next_pos
            reward = -1  # Small penalty for each step
        else:
            # Stay in place if invalid move
            reward = -1  # Still penalty for attempting invalid move

        # Check if current goal is reached
        current_goal = self.goals[self.current_goal_idx]
        if self.current_pos == current_goal:
            reward += 10  # Large reward for reaching goal

            # Mark this goal as achieved and convert to obstacle
            self.achieved_goals.add(current_goal)
            self.grid[current_goal[0], current_goal[1]] = 1  # 1 = obstacle

            self.current_goal_idx += 1

            # Check if all goals are completed
            if self.current_goal_idx >= len(self.goals):
                self.done = True
            else:
                # Reset to start position for next goal
                self.current_pos = self.start_pos

        next_state = self._get_state()

        return next_state, reward, self.done, {'position': self.current_pos}

class QLearningAgent:
    """
    Q-Learning agent with ε-greedy exploration
    """

    def __init__(self, env, alpha=0.1, gamma=0.9, epsilon=1.0, epsilon_decay=0.995, min_epsilon=0.01):
        self.env = env
        self.alpha = alpha  # Learning rate
        self.gamma = gamma  # Discount factor
        self.epsilon = epsilon  # Exploration rate
        self.epsilon_decay = epsilon_decay
        self.min_epsilon = min_epsilon

        # Q-table: defaultdict with key (state, action)
        self.Q = defaultdict(float)

        # Training statistics
        self.episode_rewards = []
        self.episode_lengths = []

    def get_action(self, state, training=True):
        """
        Select action using ε-greedy policy

        Args:
            state: Current state
            training: Whether in training mode (True) or evaluation mode (False)

        Returns:
            action: Selected action
        """
        if training and random.random() < self.epsilon:
            # Exploration: random action
            return random.choice(self.env.actions)
        else:
            # Exploitation: best action according to Q-values
            q_values = [self.Q[(state, a)] for a in self.env.actions]
            max_q = max(q_values)
            best_actions = [a for a, q in zip(self.env.actions, q_values) if q == max_q]
            return random.choice(best_actions)

    def update_q(self, state, action, reward, next_state):
        """
        Update Q-value using Bellman equation

        Q(s,a) = Q(s,a) + α[r + γ*max(Q(s',a')) - Q(s,a)]
        """
        current_q = self.Q[(state, action)]
        next_max_q = max([self.Q[(next_state, a)] for a in self.env.actions]) if not self.env.done else 0
        target = reward + self.gamma * next_max_q
        self.Q[(state, action)] = current_q + self.alpha * (target - current_q)

    def decay_epsilon(self):
        """Decay exploration rate"""
        self.epsilon = max(self.min_epsilon, self.epsilon * self.epsilon_decay)

    def train(self, num_episodes=1000, max_steps_per_episode=500):
        """
        Train the agent for a fixed number of episodes

        Args:
            num_episodes: Number of training episodes
            max_steps_per_episode: Maximum steps per episode (prevent infinite loops)

        Returns:
            episode_rewards: List of rewards for each episode
            episode_lengths: List of episode lengths
        """
        print(f"Starting Q-learning training for {num_episodes} episodes...")
        print("-" * 60)

        for episode in range(num_episodes):
            state = self.env.reset()
            episode_reward = 0
            steps = 0

            while not self.env.done and steps < max_steps_per_episode:
                action = self.get_action(state, training=True)
                next_state, reward, done, info = self.env.step(action)
                self.update_q(state, action, reward, next_state)

                state = next_state
                episode_reward += reward
                steps += 1

            # Store statistics
            self.episode_rewards.append(episode_reward)
            self.episode_lengths.append(steps)

            # Decay exploration rate
            self.decay_epsilon()

            # Print progress every 100 episodes
            if (episode + 1) % 100 == 0:
                avg_reward = sum(self.episode_rewards[-100:]) / 100
                print(".1f")

        print("Training completed!")
        print(f"Total Q-values learned: {len(self.Q)}")
        print(".3f")

        return self.episode_rewards, self.episode_lengths

    def evaluate_episode(self):
        """
        Evaluate one episode using greedy policy (no exploration)

        Returns:
            trajectory: List of (position, action, reward) tuples
            total_reward: Total reward for the episode
            steps: Number of steps taken
        """
        trajectory = []
        state = self.env.reset()
        total_reward = 0
        steps = 0

        while not self.env.done and steps < 1000:  # Prevent infinite loops
            action = self.get_action(state, training=False)  # Greedy policy
            next_state, reward, done, info = self.env.step(action)

            trajectory.append((self.env.current_pos, action, reward))
            total_reward += reward
            steps += 1

            state = next_state

        return trajectory, total_reward, steps

def plot_training_progress(rewards, title="Q-Learning Training Progress"):
    """Plot training progress (rewards over episodes)"""
    plt.figure(figsize=(12, 6))

    # Plot raw rewards
    plt.subplot(1, 2, 1)
    plt.plot(rewards, alpha=0.6, color='blue', label='Episode Rewards')
    plt.xlabel('Episode')
    plt.ylabel('Total Reward')
    plt.title('Episode Rewards')
    plt.grid(True, alpha=0.3)
    plt.legend()

    # Plot moving average
    plt.subplot(1, 2, 2)
    if len(rewards) >= 50:
        moving_avg = [sum(rewards[i:i+50])/50 for i in range(len(rewards)-49)]
        plt.plot(moving_avg, color='red', linewidth=2, label='Moving Average (50 episodes)')
    plt.xlabel('Episode')
    plt.ylabel('Average Reward')
    plt.title('Moving Average Rewards')
    plt.grid(True, alpha=0.3)
    plt.legend()

    plt.tight_layout()
    plt.suptitle(title, fontsize=14, fontweight='bold')
    plt.show()

def visualize_evaluation_episode(env, trajectory, title="Evaluation Episode"):
    """
    Visualize one evaluation episode showing the agent's path

    Args:
        env: Grid environment
        trajectory: List of (position, action, reward) tuples
        title: Plot title
    """
    fig, ax = plt.subplots(figsize=(12, 12))

    # Display maze background
    display_grid = np.where(env.grid == 1, 1, 0).astype(float)
    cmap = ListedColormap(['white', 'black'])
    ax.imshow(display_grid, cmap=cmap, origin='upper')

    # Draw goals - normal houses, achieved ones become black obstacles
    for i, (r, c) in enumerate(env.goals, 1):
        if (r, c) in env.achieved_goals:
            # Achieved goals become black obstacles
            ax.add_patch(plt.Rectangle((c-0.5, r-0.5), 1, 1, fill=True, color='black', alpha=0.9))
            ax.text(c, r, 'BLOCKED', fontsize=8, ha='center', va='center',
                    fontweight='bold', color='white')
        else:
            # Remaining goals - show as normal houses
            ax.text(c, r, '🏠', fontsize=30, ha='center', va='center')
            ax.text(c, r - 0.4, f'G{i}', fontsize=12, ha='center', va='center',
                    fontweight='bold', color='darkred',
                    bbox=dict(facecolor='white', alpha=0.9, edgecolor='none', pad=2))

    # Draw start position
    ax.text(env.start_pos[1], env.start_pos[0], 'START',
            fontsize=12, ha='center', va='center',
            bbox=dict(facecolor='green', alpha=0.8, edgecolor='black'))

    # Draw trajectory
    positions = []
    goal_changes = []
    current_goal_idx = 0

    for i, (pos, action, reward) in enumerate(trajectory):
        positions.append(pos)

        # Check if goal was reached (reward > 0 indicates goal reached)
        if reward > 0:
            goal_changes.append((len(positions)-1, current_goal_idx))
            current_goal_idx += 1

    # Plot path segments with different colors for each goal
    colors = ['blue', 'green', 'orange', 'purple', 'brown']
    start_idx = 0

    for i, (change_idx, goal_idx) in enumerate(goal_changes):
        end_idx = change_idx + 1
        segment = positions[start_idx:end_idx]

        if segment:
            path_y = [p[0] for p in segment]
            path_x = [p[1] for p in segment]
            ax.plot(path_x, path_y, 'o-', color=colors[i % len(colors)],
                   linewidth=3, markersize=8, alpha=0.8,
                   label=f'Goal {goal_idx + 1}')

        start_idx = end_idx

    # Plot remaining path
    if start_idx < len(positions):
        segment = positions[start_idx:]
        if segment:
            path_y = [p[0] for p in segment]
            path_x = [p[1] for p in segment]
            ax.plot(path_x, path_y, 'o-', color=colors[len(goal_changes) % len(colors)],
                   linewidth=3, markersize=8, alpha=0.8,
                   label=f'Final Goal')

    # Draw agent at final position
    if positions:
        final_pos = positions[-1]
        ax.text(final_pos[1], final_pos[0], 'AGENT',
                fontsize=12, ha='center', va='center',
                bbox=dict(facecolor='red', alpha=0.9, edgecolor='black'))

    # Grid and labels
    ax.set_xticks(np.arange(-0.5, env.cols, 1), minor=True)
    ax.set_yticks(np.arange(-0.5, env.rows, 1), minor=True)
    ax.grid(which='minor', color='gray', linestyle='-', linewidth=1.5, alpha=0.7)
    ax.tick_params(which='minor', size=0)
    ax.set_xticks([])
    ax.set_yticks([])

    plt.title(title, fontsize=16, fontweight='bold')
    plt.legend(loc='upper right')
    plt.tight_layout()
    plt.show()

def animate_car_movement(env, agent, delay=0.5):
    """Animate car movement step by step with popup at completion"""
    print("\n*** ANIMATING CAR MOVEMENT ***")
    print("Watch the car move step by step to each goal!")
    print("Flow: Start → Goal 1 → Reset to Start → Goal 1 becomes black → Goal 2 → Reset → Goal 2 becomes black ...")
    print("-" * 50)

    # Reset environment for clean start
    state = env.reset()
    
    # Setup matplotlib figure
    plt.ion()  # Interactive mode
    fig, ax = plt.subplots(figsize=(14, 14))  # Larger size to compensate for margins

    def redraw_grid():
        """Helper function to redraw the entire grid"""
        ax.clear()
        
        # Display maze background (includes achieved goals as obstacles)
        display_grid = np.where(env.grid == 1, 1, 0).astype(float)
        cmap = ListedColormap(['white', 'black'])
        ax.imshow(display_grid, cmap=cmap, origin='upper')

        # Draw start position
        ax.text(env.start_pos[1], env.start_pos[0], 'START',
                fontsize=12, ha='center', va='center',
                bbox=dict(facecolor='green', alpha=0.8, edgecolor='black'))

        # Draw goals - achieved ones are black obstacles, others are houses
        for i, (r, c) in enumerate(env.goals, 1):
            if (r, c) in env.achieved_goals:
                # Achieved goals become black obstacles (already in grid, but highlight)
                ax.add_patch(plt.Rectangle((c-0.5, r-0.5), 1, 1, fill=True, color='black', alpha=0.9))
                ax.text(c, r, 'BLOCKED', fontsize=10, ha='center', va='center',
                        fontweight='bold', color='white')
            else:
                # Remaining goals - show as normal houses
                ax.text(c, r, '🏠', fontsize=50, ha='center', va='center')
                ax.text(c, r - 0.4, f'G{i}', fontsize=16, ha='center', va='center',
                        fontweight='bold', color='darkred',
                        bbox=dict(facecolor='white', alpha=0.9, edgecolor='none', pad=4))

        # Grid lines
        ax.set_xticks(np.arange(-0.5, env.cols, 1), minor=True)
        ax.set_yticks(np.arange(-0.5, env.rows, 1), minor=True)
        ax.grid(which='minor', color='gray', linestyle='-', linewidth=2, alpha=0.7)
        ax.tick_params(which='minor', size=0)
        ax.set_xticks([])
        ax.set_yticks([])

    # Initial draw
    redraw_grid()
    
    # Draw car at start position
    car_text = ax.text(env.current_pos[1], env.current_pos[0], '🚗', 
                      fontsize=60, ha='center', va='center')

    # Status text - positioned at bottom left corner, completely outside the maze
    status_text = fig.text(0.02, 0.005, f'Starting at {env.start_pos}...', 
                          transform=fig.transFigure,
                          ha='left', va='bottom', fontsize=12, fontweight='bold',
                          bbox=dict(facecolor='lightblue', alpha=0.8, edgecolor='blue', linewidth=2, pad=3))

    plt.title("Car Movement Animation - Sequential Goals", fontsize=16, fontweight='bold')
    # Adjust margins to ensure status text doesn't overlap with maze (smaller margins since figsize is larger)
    plt.subplots_adjust(bottom=0.06, top=0.94, left=0.04, right=0.96)
    plt.draw()
    plt.pause(1)  # Initial pause

    total_steps = 0
    max_steps = 2000  # Prevent infinite loops

    # Main loop: use env.step() to ensure correct logic
    while not env.done and total_steps < max_steps:
        # Get current goal info
        current_goal_idx = env.current_goal_idx
        current_goal = env.goals[current_goal_idx] if current_goal_idx < len(env.goals) else None
        
        # Update status
        status_text.set_text(f'Goal {current_goal_idx + 1}/{len(env.goals)}: Moving from {env.current_pos} to Goal {current_goal_idx + 1} at {current_goal}')
        plt.draw()
        plt.pause(0.3)

        # Move towards current goal using env.step()
        goal_reached_this_cycle = False
        
        while current_goal_idx == env.current_goal_idx and not env.done and total_steps < max_steps:
            state = env._get_state()
            action = agent.get_action(state, training=False)
            
            # Execute action using env.step() - this handles goal achievement, obstacle creation, and reset
            next_state, reward, done, info = env.step(action)
            
            total_steps += 1
            
            # Check if goal was just reached (reward > 0 indicates goal reached)
            if reward > 0:
                goal_reached_this_cycle = True
                
                # Goal reached! env.current_goal_idx has already been incremented, so the achieved goal is at index (env.current_goal_idx - 1)
                achieved_goal_idx = env.current_goal_idx - 1
                achieved_goal = env.goals[achieved_goal_idx]
                
                # IMPORTANT: env.current_pos has been reset to start, but we need to show car AT goal position first
                # Show car entering and staying IN the goal cell
                car_text.set_position((achieved_goal[1], achieved_goal[0]))
                status_text.set_text(f'Goal {achieved_goal_idx + 1} REACHED at {achieved_goal}!\nCar is now IN the goal cell')
                status_text.set_bbox(dict(facecolor='lightgreen', alpha=0.8, edgecolor='green', linewidth=2))
                
                plt.draw()
                plt.pause(1.0)  # Pause 1s to see car clearly IN the goal cell
                
                # Goal becomes black obstacle - redraw grid
                redraw_grid()
                
                # Now car resets to start position (env.current_pos is already at start after step())
                car_text = ax.text(env.current_pos[1], env.current_pos[0], '🚗', 
                                  fontsize=60, ha='center', va='center')
                
                next_goal_num = env.current_goal_idx + 1 if env.current_goal_idx < len(env.goals) else len(env.goals)
                # Update status text (status_text is fig.text, so it persists after ax.clear())
                status_text.set_text(f'Reset to Start {env.start_pos}\nGoal {achieved_goal_idx + 1} is now BLACK → Next: Goal {next_goal_num}')
                status_text.set_bbox(dict(facecolor='lightblue', alpha=0.8, edgecolor='blue', linewidth=2))
                
                plt.draw()
                plt.pause(1.0)  # Pause 1s to see reset to start
                
                print(f"   Goal {achieved_goal_idx + 1} at {achieved_goal} REACHED → Car was IN goal cell → Now BLACK OBSTACLE")
                print(f"   Reset to Start {env.start_pos} → Next: Goal {next_goal_num}")
                print()
                
                break
            else:
                # Normal movement - update car position normally
                car_text.set_position((env.current_pos[1], env.current_pos[0]))
                status_text.set_text(f'Goal {current_goal_idx + 1}: {action} → {env.current_pos} (Step {total_steps}, Reward: {reward})')
                
                plt.draw()
                plt.pause(delay)
            
            if env.done:
                break

    # Final celebration
    goals_completed = len(env.achieved_goals)
    status_text.set_text(f'[COMPLETE] ALL {len(env.goals)} GOALS COMPLETED!')
    car_text.set_text('🏆')  # Trophy emoji
    plt.draw()
    plt.pause(1.0)

    # Success popup/message - ALL GOALS COMPLETED!
    print("\n" + "="*80)
    print(f"*** CONGRATULATIONS! ALL {len(env.goals)} GOALS COMPLETED! ***")
    print("="*80)
    print(f"[SUCCESS] Total steps taken: {total_steps}")
    print(f"[PERFECT] Goals completed: {goals_completed}/{len(env.goals)}")
    print("[WIN] Agent successfully navigated all sequential goals!")
    print("[BLOCKED] All achieved goals are now permanent obstacles!")
    print("="*80)
    print("*** MISSION ACCOMPLISHED! ***")
    print("="*80)

    # Keep window open for user to see
    plt.ioff()  # Turn off interactive mode
    plt.show()

    return total_steps, goals_completed

def run_animated_demo():
    """Run the animated demo with step-by-step car movement"""
    print("*** ANIMATED CAR MOVEMENT DEMO ***")
    print("=" * 60)
    print("This will show the car moving step-by-step to each goal!")
    print("Make sure to keep the matplotlib window visible.")
    print()

    # Create environment
    env = GridEnvironment()
    print(f"Grid: {env.rows}×{env.cols}, Goals: {len(env.goals)}, Start: {env.start_pos}")

    # Create and train agent
    agent = QLearningAgent(env, alpha=0.1, gamma=0.9, epsilon=1.0)
    print("Training agent for 1000 episodes...")
    agent.train(num_episodes=1000, max_steps_per_episode=200)
    print("Training completed!")

    # Reset environment to ensure clean start (no pre-achieved goals)
    env.reset()

    # Run animated evaluation
    print("\nStarting animated evaluation...")
    steps, goals_completed = animate_car_movement(env, agent, delay=0.3)

    print(f"\nDemo completed! Steps: {steps}, Goals: {goals_completed}")

def main():
    """Main function - choose demo type"""
    print("*** GRID-BASED RL WITH SEQUENTIAL GOALS ***")
    print("=" * 60)
    print("Choose demo type:")
    print("1 - Complete RL training + static visualization")
    print("2 - [ANIMATED] Car movement demo (recommended)")

    # Auto-run animated demo for better user experience
    print("Auto-starting animated car movement demo...")
    print("This will show the car moving step-by-step to each goal!")
    print()
    run_animated_demo()

def run_original_demo():
    """Run the original complete RL experiment"""
    print("GRID-BASED RL ENVIRONMENT WITH SEQUENTIAL GOALS")
    print("=" * 60)

    # Create environment
    print("1. Creating 10×10 grid environment...")
    env = GridEnvironment()
    print(f"   - Grid size: {env.rows}×{env.cols}")
    print(f"   - Start position: {env.start_pos}")
    print(f"   - Number of sequential goals: {len(env.goals)}")
    print(f"   - State space: {env.num_states} states")
    print(f"   - Action space: {len(env.actions)} actions {env.actions}")

    # Create Q-learning agent
    print("\n2. Creating Q-learning agent...")
    agent = QLearningAgent(env, alpha=0.1, gamma=0.9, epsilon=1.0)

    # Training
    print("\n3. Training agent...")
    start_time = time.time()
    rewards, lengths = agent.train(num_episodes=1000)
    training_time = time.time() - start_time
    print(f"   - Training time: {training_time:.2f}s")

    # Plot training progress
    print("\n4. Plotting training progress...")
    plot_training_progress(rewards, "Q-Learning Training on Sequential Goals")

    # Evaluate using greedy policy
    print("\n5. Evaluating with greedy policy...")
    trajectory, eval_reward, eval_steps = agent.evaluate_episode()
    print(f"   - Evaluation reward: {eval_reward}")
    print(f"   - Evaluation steps: {eval_steps}")
    print(f"   - Trajectory length: {len(trajectory)}")

    # Visualize evaluation episode
    print("\n6. Visualizing evaluation episode...")
    visualize_evaluation_episode(env, trajectory,
                                f"Sequential Goals Navigation (Reward: {eval_reward}, Steps: {eval_steps})")

    # Final statistics
    print("\n" + "=" * 60)
    print("FINAL STATISTICS:")
    print(f"Total training episodes: 1,000")
    print(f"Training time: {training_time:.2f}s")
    print(f"Total Q-values learned: {len(agent.Q)}")
    print(f"Final epsilon: {agent.epsilon:.3f}")
    print(f"Evaluation performance: {eval_reward} reward, {eval_steps} steps")
    print("Training completed successfully!")

# Test function for goals becoming obstacles
def test_obstacle_goals():
    """Test the new feature where achieved goals become obstacles"""
    print("*** TESTING: GOALS BECOMING OBSTACLES ***")
    print("=" * 50)

    env = GridEnvironment()
    agent = QLearningAgent(env, alpha=0.1, gamma=0.9, epsilon=1.0)

    # Quick training
    print("Training for 200 episodes...")
    agent.train(num_episodes=200, max_steps_per_episode=100)

    # Test evaluation
    print("\nTesting obstacle functionality...")
    trajectory, reward, steps = agent.evaluate_episode()

    print("\n*** RESULTS ***")
    print(f"   - Total steps: {steps}")
    print(f"   - Final reward: {reward}")
    print(f"   - Achieved goals: {len(env.achieved_goals)}")
    print(f"   - Obstacle positions: {sorted(env.achieved_goals)}")

    # Check if grid has obstacles at achieved goal positions
    obstacle_check = []
    for goal in env.achieved_goals:
        if env.grid[goal[0], goal[1]] == 1:
            obstacle_check.append(f"[OK] {goal}")
        else:
            obstacle_check.append(f"[FAIL] {goal}")

    print(f"   - Grid obstacles verified: {obstacle_check}")

    print("\n*** Test completed! ***")

def test_goal_visualization():
    """Test goal visualization - should show houses initially, become black when reached"""
    print("*** TESTING GOAL VISUALIZATION ***")
    print("=" * 50)

    env = GridEnvironment()

    # Before any goals achieved - all should be houses
    print("Before any goals achieved:")
    print(f"  - Achieved goals: {len(env.achieved_goals)} (should be 0)")
    print("  - All goals should display as HOUSE emoji")

    # Simulate reaching first goal
    print("\nSimulating reaching Goal 1...")
    env.current_pos = env.goals[0]  # Move to goal 1
    env.step('UP')  # This should trigger goal achievement

    print("After reaching Goal 1:")
    print(f"  - Achieved goals: {len(env.achieved_goals)} (should be 1)")
    print("  - Goal 1 should be BLOCKED (black)")
    print("  - Other goals should still be HOUSE emoji")

    # Reset and try again
    print("\nResetting environment...")
    env.reset()
    print(f"After reset - Achieved goals: {len(env.achieved_goals)} (should be 0)")

    print("\n*** Visualization test completed! ***")

if __name__ == "__main__":
    # Uncomment to test visualization
    # test_goal_visualization()

    main()